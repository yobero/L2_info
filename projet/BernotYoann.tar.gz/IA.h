#include "fonction.h"

int IAJoueur(POINT utilisateur);

JOUEUR deplaceIA(JOUEUR IA,JOUEUR j);

JOUEUR placementIA(JOUEUR IA,JOUEUR j);
