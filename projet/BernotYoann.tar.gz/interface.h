#include "affichage.h"

void boutonTemporaire();

void bouton ();

void message(int n);

void fenetreInterface(int quiJoue);

void interface(int quiJoue);

void dessinePlateau(int quiJoue); // La fonction va déssiner le plateau du jeu
