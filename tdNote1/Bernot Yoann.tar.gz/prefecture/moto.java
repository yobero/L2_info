
/**
 * Write a description of class moto here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class moto extends vehicule
{
    /**
     * Constructor for objects of class moto
     */
    public moto(String immatriculation, String modele, String proprietaire)
    {
        this.type = "moto";
        this.immatriculation = immatriculation;
        this.modele = modele;
        this.proprietaire = proprietaire;
        
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
}