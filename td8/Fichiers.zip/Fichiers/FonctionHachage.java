
public interface FonctionHachage {

	// Fonction de hachage. Le troisieme parametre est la taille de la table de hachage

	public int hashFunction(double latitude, double longitude, int m);
}